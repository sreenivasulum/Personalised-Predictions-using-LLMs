import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import './App.css';
import Tweetsdash from './Tweetsdash';
import Banner from './components/Banner';
import Sample from './components/Sample';
import MovieSearch from './components/MovieSearch';
import LLMComponent from './components/LLMComponent';
import TwitterTweets from './components/TwitterTweets';
import Dashboard from './components/Dashboard';
import Recommendation from './components/Recommendation';

function App() {
  const [selectedMovies, setSelectedMovies] = useState([]);
  const [selectedBooks, setSelectedBooks] = useState([]);
  const [selectedTweets, setSelectedTweets] = useState([]);

  const handleSelectedBooksChange = (books) => {
    setSelectedBooks(books);
  };

  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Banner />} />
        <Route path="/watchlist" element={<MovieSearch setSelectedMovies={setSelectedMovies} />} />
        <Route path="/twitter" element={<Dashboard setSelectedTweets={setSelectedTweets}/>} />
        <Route path="/graphs" element={<Recommendation/>} />
        <Route path="/llm" element={<LLMComponent selectedMovies={selectedMovies} selectedBooks={selectedBooks} tweets={selectedTweets}/>} />
       
      </Routes>
      <div className="flex flex-row space-x-4 p-4 overflow-x-auto">
        <Sample onSelectedBooksChange={handleSelectedBooksChange}/>
      </div>
    </BrowserRouter>
  );
}

export default App;
