import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';

const data = [
  { category: 'Clothing', count: 120 },
  { category: 'Shoes', count: 80 },
  { category: 'Jewelry', count: 50 },
  { category: 'Movies', count: 200 },
  { category: 'Sports', count: 150 },
  { category: 'Tweets', count: 300 },
];

const CustomBarChart = () => (
  <BarChart width={600} height={300} data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
    <CartesianGrid strokeDasharray="3 3" />
    <XAxis dataKey="category" />
    <YAxis />
    <Tooltip />
    <Legend />
    <Bar dataKey="count" fill="#8884d8" />
  </BarChart>
);

export default CustomBarChart;
