import React from 'react'

import {Link} from "react-router-dom";

import Logo from "../books.jpeg"
const Navbar = () => {
  return (
    <div className='flex border space-x-8 items-center pl-3 py-4'>
         
         <img className='w-[50px]' src={Logo} alt="" />
         
         <Link to='/' className='text-blue-500 text-3xl font-bold'> Home</Link>
         <Link to='/watchlist' className='text-blue-500 text-3xl font-bold'> Movies</Link>
         <Link to='/twitter' className='text-blue-500 text-3xl font-bold'> Twitter</Link>
        {/* <Link to='/graphs' className='text-blue-500 text-3xl font-bold'> User Insights</Link>*/}
         <Link to='/llm' className='text-blue-500 text-3xl font-bold'> Recommendation</Link>
         
    </div>
  )
}

export default Navbar