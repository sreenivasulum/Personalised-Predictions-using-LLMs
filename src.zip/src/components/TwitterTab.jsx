import React from 'react'

function TwitterTab() {
  return (
    <div>
        <h1>This is twitter component</h1>
    </div>
  )
}

export default TwitterTab