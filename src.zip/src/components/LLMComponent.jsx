import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BarChart, Bar, LineChart, Line, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Papa from 'papaparse';
import WordCloudGraph from './WordCloudGraph';
import CustomBarChart from './CustomBarChart';
import CustomPieChart from './CustomPieChart';
import WordCloudComponent from './WordCloudComponent';

const LLMComponent = ({ tweets, selectedBooks, selectedMovies }) => {
  const [recommendedBooks, setRecommendedBooks] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [csvData, setCsvData] = useState([]);
  const [ratingData, setRatingData] = useState([]);
  const [timeSeriesData, setTimeSeriesData] = useState([]);
  const [scatterData, setScatterData] = useState([]);
  const [reviewSentences, setReviewSentences] = useState([]);
  const [featureSentences, setFeatureSentences] = useState([]);

  useEffect(() => {
    // Load CSV files
    loadCsvData('/finalmetabooks.csv'); // Replace with the path to your CSV file
  }, []);

  const loadCsvData = (filePath) => {
    Papa.parse(filePath, {
      download: true,
      header: true,
      complete: (results) => {
        setCsvData(results.data);
      },
      error: (error) => {
        console.error('Error loading CSV data:', error);
      },
    });
  };

  const handleRecommendation = async () => {
    if (tweets.length === 0 && selectedBooks.length === 0 && selectedMovies.length === 0) {
      setError("Please select at least one book, movie, or tweet for recommendations.");
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.post('http://127.0.0.1:6005/recommend', {
        tweets: tweets.map(tweet => tweet.text),
        selected_books: selectedBooks.map(book => book.title),
        selected_movies: selectedMovies.map(movie => movie.title),
      });
      console.log('Response data:', response.data);

      if (response.data && response.data.recommendation) {
        const recommendation = response.data.recommendation;
        const parts = recommendation.split('\nReason: ');
        const bookTitle = parts[0].replace('Recommended Book: ', '').replace(/["']/g, "").trim(); // Trim whitespace

        const recommendedBookData = csvData.filter(book => book.title === bookTitle);
        if (recommendedBookData.length === 0) {
          setError(`No data found for recommended book: ${bookTitle}`);
          return;
        }

        setRecommendedBooks([{ title: bookTitle, reason: parts[1], ...recommendedBookData[0] }]);
        prepareChartData(recommendedBookData);
        fetchReviewData(recommendedBookData[0]); // Fetch review data for the recommended book
      } else {
        console.error('No recommendation in response:', response.data);
        setError('No recommendation received.');
      }
    } catch (error) {
      console.error('Error getting recommendation:', error);
      setError('An error occurred while fetching recommendations. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const prepareChartData = (recommendedBookData) => {
    const ratingCounts = {};
    const ratingsOverTime = [];
    const averageRatingVsPrice = [];

    recommendedBookData.forEach(book => {
      // Ratings vs. Number of Users
      const rating = parseFloat(book.rating);
      if (ratingCounts[rating]) {
        ratingCounts[rating]++;
      } else {
        ratingCounts[rating] = 1;
      }

      // Ratings Over Time
      const timestamp = new Date(book.timestamp); // Convert timestamp to Date object
      ratingsOverTime.push({ x: timestamp.getTime(), y: rating });

      // Average Rating vs. Price
      averageRatingVsPrice.push({ x: parseFloat(book.average_rating), y: parseFloat(book.price) });
    });

    // Set chart data
    setRatingData(Object.entries(ratingCounts).map(([key, value]) => ({ rating: key, count: value })));
    setTimeSeriesData(ratingsOverTime);
    setScatterData(averageRatingVsPrice);
  };

  const fetchReviewData = (recommendedBookData) => {
    if (recommendedBookData) {
      const reviews = recommendedBookData.review.split('. '); // Split reviews into sentences
      const features = recommendedBookData.features.split('. '); // Split features into sentences
      setReviewSentences(reviews);
      setFeatureSentences(features); // Set the sentences for the features word cloud
    }
  };

  return (
    <div className="container mx-auto p-4">
      {/*<h2 className="text-2xl font-bold mb-4">LLM Recommendations</h2>*/}

      {error && (
        <div className="mb-4 p-2 bg-red-100 text-red-700 border border-red-400 rounded">
          {error}
        </div>
      )}

      {/* Selected Movies and Books */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
        <div className="grid grid-cols-1 gap-4">
          <h2 className="text-xl font-bold mb-4">Selected Movies for LLM Component</h2>
          <div className="grid grid-cols-2 gap-4">
            {selectedMovies.map((movie) => (
              <div
                key={movie.id}
                className="relative h-60 rounded-xl bg-gray-200 flex-shrink-0"
                style={{ minWidth: '200px' }}
              >
                <div
                  className="h-full w-full bg-center bg-cover rounded-xl"
                  style={{ backgroundImage: `url(${movie.poster_path ? `https://image.tmdb.org/t/p/w200${movie.poster_path}` : ''})` }}
                ></div>
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-60 text-white p-2 rounded-b-xl">
                  <p className="text-sm font-bold text-center">{movie.title}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          <h2 className="text-xl font-bold mb-4">Selected Books for LLM Component</h2>
          <ul className="grid grid-cols-2 gap-4">
            {selectedBooks.map((book, index) => (
              <li key={index} className="p-2 border border-gray-200 rounded-md flex items-center">
                <img src={book.image_url} alt={book.title} className="w-50 h-50 mr-4 object-cover" />
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Recommendation Button */}
      <div className="mt-8 text-center">
        <button
          className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors"
          onClick={handleRecommendation}
          disabled={isLoading}
        >
          {isLoading ? 'Loading...' : 'Get Recommendation'}
        </button>
      </div>

      {/* Recommended Books */}
      {Array.isArray(recommendedBooks) && recommendedBooks.length > 0 && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Recommended Books</h2>
          <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {recommendedBooks.map((book, index) => (
              <li key={index} className="p-4 border border-gray-300 bg-white rounded-md shadow-md">
                <p className="font-bold text-lg text-blue-700 mb-2">{book.title}</p>
                <p className="text-gray-700">{book.reason}</p>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* User Insights Section */}
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4">User Insights</h2>

        {/* Custom Pie Chart */}
        <div className="bg-white p-4 rounded-md shadow-md mt-4">
          <h3 className="text-lg font-bold mb-2">Pie chart for user history</h3>
          <CustomPieChart />
        </div>

        {/* Custom Bar Chart */}
        <div className="bg-white p-4 rounded-md shadow-md mt-4">
          <h3 className="text-lg font-bold mb-2">Bar Chart for users history</h3>
          <CustomBarChart />
        </div>

        {/* Word Cloud Component */}
        <div className="bg-white p-4 rounded-md shadow-md mt-4">
          <h3 className="text-lg font-bold mb-2">User Tweets </h3>
          {tweets && tweets.length > 0 && <WordCloudComponent tweets={tweets} />}
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        {/* Ratings vs. Number of Users */}
        <div className="bg-white p-4 rounded-md shadow-md">
          <h3 className="text-lg font-bold mb-2">Ratings vs. Number of Users</h3>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={ratingData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="rating" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="rgba(75, 192, 192, 0.6)" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Ratings Over Time */}
        <div className="bg-white p-4 rounded-md shadow-md">
          <h3 className="text-lg font-bold mb-2">Ratings Over Time</h3>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={timeSeriesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="x"
                tickFormatter={(tick) => new Date(tick).toLocaleDateString()}
                label={{ value: 'Time', position: 'insideBottomRight', offset: -5 }}
              />
              <YAxis label={{ value: 'Rating', angle: -90, position: 'insideLeft' }} />
              <Tooltip labelFormatter={(label) => new Date(label).toLocaleDateString()} />
              <Legend />
              <Line type="monotone" dataKey="y" stroke="rgba(75, 192, 192, 1)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Average Rating vs Price */}
        <div className="bg-white p-4 rounded-md shadow-md">
          <h3 className="text-lg font-bold mb-2">Average Rating vs Price</h3>
          <ResponsiveContainer width="100%" height={400}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="x" name="Average Rating" />
              <YAxis dataKey="y" name="Price" />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Legend />
              <Scatter data={scatterData} fill="rgba(75, 192, 192, 0.6)" />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Reviews and Features Word Clouds */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
        {/* Reviews Word Cloud */}
        <div className="bg-white p-4 rounded-md shadow-md">
          <h2 className="text-2xl font-bold text-center text-blue-700">Reviews</h2>
          <WordCloudGraph sentences={reviewSentences} />
        </div>

        {/* Features Word Cloud */}
        <div className="bg-white p-4 rounded-md shadow-md">
          <h2 className="text-2xl font-bold text-center text-blue-700">Features</h2>
          <WordCloudGraph sentences={featureSentences} />
        </div>
      </div>
    </div>
  );
};

export default LLMComponent;
