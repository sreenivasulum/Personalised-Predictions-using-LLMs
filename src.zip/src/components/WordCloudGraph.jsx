import React from 'react';
import WordCloud from 'react-wordcloud';

const WordCloudGraph = ({ sentences }) => {
  // Combine all sentences into a single string
  const text = sentences.join(" ");

  // Split the text into words and count the occurrences of each word
  const wordCounts = text.split(/\s+/).reduce((counts, word) => {
    const cleanedWord = word.replace(/[.,]/g, '').toLowerCase();
    counts[cleanedWord] = (counts[cleanedWord] || 0) + 1;
    return counts;
  }, {});

  // Convert the word counts into an array of objects for the word cloud
  const words = Object.keys(wordCounts).map(word => ({
    text: word,
    value: wordCounts[word]
  }));

  const options = {
    rotations: 2,
    rotationAngles: [-90, 0],
    fontSizes: [20, 60]
  };

  return (
    <div style={{ height: 400, width: 800 }}>
      <WordCloud words={words} options={options} />
    </div>
  );
};

export default WordCloudGraph;
