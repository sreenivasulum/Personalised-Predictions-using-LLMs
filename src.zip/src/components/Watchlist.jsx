import React from 'react'

function Watchlist() {
  return (
    <div>

        <h1>This is watchlist<h1/>

    </div>
  )
}

export default Watchlist